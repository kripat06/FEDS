from chalice import Chalice, Response
import boto3
import os


app = Chalice(app_name="feds_upload_api")

BUCKET = 'kpat-esp32fedsupload-west-2'  # bucket name
s3_client = boto3.client('s3')
s3_resource = boto3.resource('s3')

@app.route("/healthcheck", api_key_required=True)
def index():
    return {"Status": "running"}

@app.lambda_function()
def cv2_import(event, context):
    import cv2
    return {'cv2': boto3.__file__}

@app.route('/upload/{file_name}', methods=['POST'],
           content_types=['application/octet-stream'], api_key_required=True)
def upload_to_s3(file_name):

    # get raw body of PUT request
    body = app.current_request.raw_body

    # write body to tmp file
    tmp_file_name = '/tmp/' + file_name
    with open(tmp_file_name, 'wb') as tmp_file:
        tmp_file.write(body)

    # upload tmp file to s3 bucket
    s3_client.upload_file(tmp_file_name, BUCKET, file_name)

    return Response(body='upload successful: {}'.format(file_name),
                    status_code=200)


@app.on_s3_event(bucket=BUCKET)
def s3_handler(event):
    #save tp /tmp/<year-month-date-hour-min>/
    # /s3/<loc>/<year>/<month>/

    print(event.key)
    tmp_path = '/tmp/' + event.key

    print(f"Downloading {event.key} to location {tmp_path}")

    bucket = s3_resource.Bucket(BUCKET)
    bucket.download_file(event.key, tmp_path)

    print("Image " + event.key + " saved into " + tmp_path)

    if os.path.exists(tmp_path):
        print("Image exists at: " +tmp_path)
    else:
        print("Image not found")

# def check_empty_img(img):
#     image = cv2.imread(img)
#     if image is None:
#         result = "Image at" + img + "does not exist"
#     else:
#         result = "Image at" + img + "does exist"
#
#     return result